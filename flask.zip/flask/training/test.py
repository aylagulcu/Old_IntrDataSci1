from flask import request, Flask

app = Flask(__name__)

with app.test_request_context('/cookie', method='GET'):
    assert request.method == 'GET'
    assert request.path == '/cookie'


@app.route('/other')
def other():
    return 'Other page in other .py'
