### About basic flask web framework application and some training

##### Requirements

-   For all dependencies, run command in current directory which includes requirements.txt as follows:

>   pip install -r requirements.txt