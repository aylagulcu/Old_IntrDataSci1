from flask import Flask
from flask import request
from flask import render_template, redirect, url_for
from flask import Response
import os

app = Flask(__name__)


@app.route("/")
def index():
    app.logger.info('here is index page / ')
    return "Hello Index page!"


@app.route('/user')
def show_users():
    # show the user profile for that user
    return 'User page'


@app.route('/user/<username>')
def show_user_profile(username):
    # show the user profile for that user
    return 'User %s' % username


@app.route('/post')
@app.route('/post/<int:post_id>')
def show_post(post_id=-1):
    # show the post with the given id, the id is an integer
    return 'Post %d' % post_id


@app.route('/method', methods=['GET', 'POST', 'PUT'])
def method_test():
    if request.method == 'GET':
        return 'GET method'
    elif request.method == 'POST':
        return 'POST method'
    else:
        return 'Another HTTP method'


@app.route('/template/')
@app.route('/template/<name>')
def hello(name=None):
    return render_template('hello.html', name=name)


@app.route('/parameter')
def param():
    return request.args.get('name', '')


@app.route('/form', methods=['POST'])
def post_form():
    args = 'username: ' + request.form['username'] + "\n" + 'email:' + request.form['email'] + "\n" + 'web:' + \
            request.form['web']
    return args


@app.route('/cookie')
def cookie():
    redirection = redirect('/cookieokay')
    response = app.make_response(redirection)
    response.set_cookie("username", "okan")
    return response


@app.route('/cookieokay')
def cookie_okay():
    return 'cookie okay'


@app.route('/request_header')
def get_request_header():
    header = request.headers.get('User-Agent')
    return "Content-Type: %s" % header


@app.route('/response_header')
def get_response_header():
    response = Response('Pretty Response')
    return response.headers['Content-Type']


@app.route('/redirect_to_index')
def redirect_to_index():
    return redirect(url_for('index'))


@app.route('/other_redirect')
def other_redirect():
    return redirect('/', code=302, Response=None)


@app.route('/debug')
def debug_test():
    return "Debug test"


@app.errorhandler(404)
def page_not_found(error):
    # 404 that returns, ensure the 404 code response
    return render_template('404.html'), 404


@app.route('/abort')
def abort():
    abort(401)
    return 'No executed'


app.secret_key = os.urandom(24)


@app.route('/session')
def session():
    username = 'user_name'
    session['username'] = username


@app.route('/show_session')
def show_session():
    return session['username']


if __name__ == "__main__":
    app.run(debug=True, port=8888)
