import os
import sqlite3
import util

from flask import Flask, request, session, g, redirect, url_for, abort, render_template, flash, send_from_directory
from werkzeug.utils import secure_filename

# configuration
DATABASE = '/tmp/app.db'
DEBUG = True
SECRET_KEY = os.urandom(24)
USERNAME = 'admin'
PASSWORD = 'default'

app = Flask(__name__)
app.config.from_object(__name__)
# This is the path to the upload directory
app.config['UPLOAD_FOLDER'] = 'uploads/'
# These are the extension that we are accepting to be uploaded
app.config['ALLOWED_EXTENSIONS'] = {'py', 'png', 'jpg', 'jpeg', 'gif'}


def connect_db():
    return sqlite3.connect(app.config['DATABASE'])


@app.before_request
def before_request():
    g.db = connect_db()


# use the teardown_request because of exceptions
@app.teardown_request
def tear_down_request(exception):
    db = getattr(g, 'db', None)
    if db is not None:
        db.close()


@app.route('/')
def show_entries():
    cur = g.db.execute('select title, text, file_name, source_code, lang from entries order by id desc')
    entries = [dict(title=row[0], text=row[1], filename=row[2], source_code=row[3], lang=row[4]) for row in cur.fetchall()]
    return render_template('show_entries.html', entries=entries)


@app.route('/add', methods=['POST'])
def add_entry():
    if not session.get('logged_in'):
        abort(401)
    file = request.files['file']
    filename = None
    if file and util.allowed_file(file.filename, app):
        filename = secure_filename(file.filename)
        file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
        print(filename)
    g.db.execute('insert into entries (title, text, file_name, source_code, lang) values (?, ?, ?, ?, ?)',
                 [request.form['title'], request.form['text'], filename, request.form['source'], request.form['lang']])
    g.db.commit()
    flash('New entry was successfully posted')
    return redirect(url_for('show_entries'))


@app.route('/login', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        if request.form['username'] != app.config['USERNAME']:
            error = 'Invalid username'
        elif request.form['password'] != app.config['PASSWORD']:
            error = 'Invalid password'
        else:
            session['logged_in'] = True
            flash('You were logged in')
            return redirect(url_for('show_entries'))
    return render_template('login.html', error=error)


@app.route('/logout')
def logout():
    session.pop('logged_in', None)
    flash('You were logged out')
    return redirect(url_for('show_entries'))


@app.route('/uploads/<img>')
def uploaded_file(img):
    return send_from_directory(app.config['UPLOAD_FOLDER'],
                               img)


if __name__ == '__main__':
    app.run(host='172.16.19.5', port=8888)
